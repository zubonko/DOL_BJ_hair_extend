Degrees of Lewdity
庫褲子BJ美化包髮型擴充 - 使用說明

1.下載最新版DOL -> https://github.com/Eltirosto/Degrees-of-Lewdity-Chinese-Localization/releases/tag/v0.4.3.3-chs-alpha2.0.1

2.下載含BJ美化的模組整合包 -> https://github.com/sakarie9/DOL-CHS-MODS

3.下載並解壓縮此檔案{Dol_hair_v1.x}

4.將檔案{IMG}拖至你的DOL遊戲資料夾內，覆蓋所有相同項目

-------------------------------------------------------------------------
BJ Hairstyle Extension - By ZUBONKO - Instructions for Use

1. Download the latest version of DOL -> https://vrelnir.blogspot.com/?zx=ba6dc80dda374e0c

2. Download MOD {Papa Paril BEEESSS Burger Joint} -> https://gitgud.io/GTXMEGADUDE/papa-paril-burger-joint

3. Download and unzip this file {Dol_hair_v1.x}

4. Drag the file {IMG} into your DOL game folder and cover all the same items

